import os
import shutil
import argparse
import logging
import sys
import time
from pathlib import Path

# Third-party libraries (run: pip install pyyaml colorama)
import yaml
from colorama import Fore, Style, init

# Initialize Colorama for colored output
init(autoreset=True)

# --- CONFIGURATION & SETUP ---
def load_config(config_path='config.yaml'):
    """Loads all rules from the YAML config file."""
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        if not isinstance(config, dict):
            print(f"{Fore.RED}FATAL ERROR: `config.yaml` is empty or malformed."); exit()
        
        destination_map = config.get('destination_map', {})
        extension_map = {ext: folder for folder, exts in destination_map.items() for ext in exts}
        fallback_folder = config.get('fallback_folder', 'Other')
        cleanup_config = config.get('cleanup_rules', {'enabled': False})
        
        return extension_map, fallback_folder, destination_map, cleanup_config
    except FileNotFoundError:
        print(f"{Fore.RED}FATAL ERROR: `config.yaml` not found. Please create it next to the script."); exit()
    except Exception as e:
        print(f"{Fore.RED}FATAL ERROR: Could not parse `config.yaml`. Error: {e}"); exit()

# --- INTELLIGENT DETECTION LOGIC ---
def is_project_folder(folder_path: Path) -> str | None:
    """Detects if a folder is a development project."""
    if (folder_path / ".git").is_dir(): return "Project (Git Repo)"
    if any((folder_path / f).exists() for f in ["requirements.txt", "pyproject.toml", "setup.py"]): return "Project (Python)"
    if (folder_path / "package.json").exists(): return "Project (Node.js)"
    if (folder_path / "index.html").exists() and any((folder_path / d).is_dir() for d in ["css", "js"]): return "Project (Web)"
    return None

def is_application_folder(folder_path: Path) -> bool:
    """Heuristic to check if a folder contains a runnable application to protect it."""
    try:
        # Check only the top-level of the folder for performance and accuracy
        has_exe = any(item.suffix.lower() == '.exe' for item in folder_path.iterdir() if item.is_file())
        dll_count = sum(1 for item in folder_path.iterdir() if item.is_file() and item.suffix.lower() == '.dll')
        # A folder with an EXE and several DLLs is very likely an application
        return has_exe and dll_count >= 3
    except (OSError, PermissionError):
        # If we can't read the folder, assume it's protected and skip it
        return False

# --- CORE UTILITIES ---
def get_unique_path(destination_path: Path) -> Path:
    """Ensures a file path is unique by appending a number if it already exists."""
    if not destination_path.exists(): return destination_path
    parent, stem, suffix = destination_path.parent, destination_path.stem, destination_path.suffix
    counter = 1
    while True:
        new_path = parent / f"{stem} ({counter}){suffix}"
        if not new_path.exists(): return new_path
        counter += 1

# --- SORTER LOGIC ---
def sort_directory(source_dir: Path, dest_dir: Path, config: tuple, dry_run: bool, auto_confirm: bool):
    """Sorts a directory, intelligently skipping application folders and installers."""
    extension_map, fallback_folder, destination_map_raw, _ = config
    top_level_dest_folders = {Path(p).parts[0] for p in destination_map_raw.keys()}
    top_level_dest_folders.add(fallback_folder)

    for item in list(source_dir.iterdir()):
        if item.name.startswith('.') or item.name in top_level_dest_folders:
            continue

        if item.is_dir():
            if is_project_folder(item):
                project_type = is_project_folder(item)
                print(f"{Fore.YELLOW}-> Detected '{item.name}' as a '{project_type}'.")
                confirm = 'y' if auto_confirm else input(f"   Move entire folder to '{dest_dir / 'Development/Projects'}'? (y/n): ").lower()
                if confirm == 'y':
                    dest_path = get_unique_path(dest_dir / "Development/Projects" / item.name)
                    print(f"{Fore.GREEN}MOVE PROJECT: '{item}' -> '{dest_path}'")
                    logging.info(f"MOVE_PROJECT: '{item}' -> '{dest_path}'")
                    if not dry_run:
                        dest_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(item), str(dest_path))
                else:
                    print(f"{Fore.MAGENTA}SKIPPING Project Folder: '{item.name}'")
                continue

            if is_application_folder(item):
                print(f"{Fore.MAGENTA}SKIPPING Application Folder: '{item.name}' (contains .exe and .dlls)")
                logging.info(f"SKIP_APP: Skipped application folder '{item.name}'")
                continue

            print(f"{Fore.CYAN}-> Found sub-folder '{item.name}'.")
            confirm = 'y' if auto_confirm else input("   Sort its contents? (y/n): ").lower()
            if confirm == 'y':
                sort_directory(item, dest_dir, config, dry_run, auto_confirm)
            else:
                print(f"{Fore.MAGENTA}SKIPPING Folder: '{item.name}'")

        elif item.is_file():
            if item.suffix.lower() in ['.exe', '.msi', '.dmg']:
                print(f"{Fore.MAGENTA}SKIPPING Installer/Executable: '{item.name}'")
                logging.info(f"SKIP_EXE: Skipped individual installer/executable '{item.name}'")
                continue

            target_subfolder = extension_map.get(item.suffix.lower(), fallback_folder)
            final_dest_dir = dest_dir / target_subfolder
            final_dest_path = get_unique_path(final_dest_dir / item.name)
            print(f"{Fore.GREEN}MOVE FILE: '{item}' -> '{final_dest_path}'")
            logging.info(f"MOVE_FILE: '{item}' -> '{final_dest_path}'")
            if not dry_run:
                final_dest_dir.mkdir(parents=True, exist_ok=True)
                shutil.move(str(item), str(final_dest_path))

# --- ADVANCED CLEANUP FUNCTION (THE SMARTER BRAIN 2.0) ---
def cleanup_useless_files(target_dir: Path, cleanup_config: dict, dry_run: bool):
    """Finds and deletes files with enhanced intelligence and safety checks."""
    if not cleanup_config.get('enabled', False):
        print(f"{Fore.YELLOW}Advanced cleanup is disabled in config.yaml. Skipping."); return

    print(f"\n{Fore.RED}{Style.BRIGHT}{'='*15} Advanced Cleanup Mode {'='*15}")
    print(f"{Fore.YELLOW}Scanning '{target_dir}' with Smarter Brain 2.0...")

    rules = cleanup_config
    protected_paths = [str(target_dir / p) for p in rules.get('protected_folders', [])]
    protected_age_exts = {e.lower() for e in rules.get('protected_from_age_rule_extensions', [])}
    
    files_to_delete = []
    
    for root, dirs, files in os.walk(target_dir, topdown=True):
        # Prune search tree for safety and performance
        if any(root.startswith(p) for p in protected_paths):
            print(f"{Fore.CYAN}SKIPPING cleanup in manually protected directory: {root}")
            dirs.clear(); continue
        if is_application_folder(Path(root)):
            print(f"{Fore.CYAN}SKIPPING cleanup in detected application directory: {root}")
            dirs.clear(); continue

        for filename in files:
            file_path = Path(root) / filename
            reason = ""
            try:
                file_ext = file_path.suffix.lower()
                # Rule 1 & 2: Junk names and extensions (always apply)
                if filename.lower() in [n.lower() for n in rules.get('delete_filenames', [])]:
                    reason = f"Junk filename ('{filename}')"
                elif file_ext in [e.lower() for e in rules.get('delete_extensions', [])]:
                    reason = f"Junk extension ('{file_ext}')"
                # Rule 3: Empty files (always apply)
                elif rules.get('delete_empty_files') and file_path.stat().st_size == 0:
                    reason = "Empty file (0 bytes)"
                # Rule 4: THE SMARTER AGE RULE
                elif rules.get('delete_older_than_days', 0) > 0 and file_ext not in protected_age_exts:
                    if file_path.stat().st_mtime < (time.time() - rules['delete_older_than_days'] * 86400):
                        reason = f"Old non-critical file (>{rules['delete_older_than_days']} days)"
                
                if reason:
                    files_to_delete.append((file_path, reason))
            except (FileNotFoundError, PermissionError):
                pass

    if not files_to_delete:
        print(f"{Fore.GREEN}No disposable files found matching your criteria."); return

    print(f"\n{Fore.YELLOW}{Style.BRIGHT}Found {len(files_to_delete)} disposable files:")
    for path, reason in files_to_delete:
        print(f"  - {Fore.RED}{path} {Style.DIM}(Reason: {reason})")

    if dry_run:
        print(f"\n{Fore.YELLOW}DRY RUN: No files were deleted."); return

    print(f"\n{Fore.RED}{Style.BRIGHT}!! WARNING !! YOU ARE ABOUT TO PERMANENTLY DELETE THESE FILES. !!")
    confirm = input(f"Type '{Fore.RED}DELETE{Style.RESET_ALL}' to confirm and delete these {len(files_to_delete)} files: ")
    if confirm == "DELETE":
        deleted_count = 0
        for path, reason in files_to_delete:
            try:
                os.remove(path)
                print(f"{Fore.YELLOW}DELETED: {path}")
                logging.warning(f"DELETE: User confirmed deletion of '{path}' (Reason: {reason})")
                deleted_count += 1
            except Exception as e:
                print(f"{Fore.RED}ERROR: Could not delete {path}. Reason: {e}")
                logging.error(f"DELETE_FAIL: Could not delete '{path}': {e}")
        print(f"\n{Fore.GREEN}Cleanup complete. Permanently deleted {deleted_count} files.")
    else:
        print("\nOperation cancelled. No files were deleted.")

# --- SCRIPT EXECUTION ---
if __name__ == "__main__":
    home = Path.home()
    default_source = home / "Downloads"
    default_dest = home / "Documents"

    parser = argparse.ArgumentParser(
        description="The Ultimate File Sorter - a powerful, intelligent, and safe file organizer.",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=f"""
{Style.BRIGHT}Examples:{Style.NORMAL}
  1. Interactive Dry Run (Sort Downloads -> Documents):
     {sys.argv[0]} --dry-run

  2. Unattended Sort (No Questions Asked):
     {sys.argv[0]} -y

  3. Organize Documents folder IN-PLACE, unattended:
     {sys.argv[0]} "{default_dest}" "{default_dest}" -y
     
  4. {Fore.RED}Sort AND Cleanup old files (Dry Run):{Style.NORMAL}
     {sys.argv[0]} --dry-run --cleanup-advanced

{Fore.RED}{Style.BRIGHT}WARNING:{Style.NORMAL}{Fore.RED} This script can move and permanently delete files. 
Always use --dry-run first and back up your data.{Style.RESET_ALL}
"""
    )
    parser.add_argument("source", nargs='?', default=str(default_source), help="The source directory to sort.")
    parser.add_argument("destination", nargs='?', default=str(default_dest), help="The destination root directory.")
    parser.add_argument("--dry-run", action="store_true", help="Simulate all operations without changing any files.")
    parser.add_argument("-y", "--yes", action="store_true", help="Automatically answer 'yes' to all sorting prompts.")
    parser.add_argument("--cleanup-advanced", action="store_true", help="[DANGEROUS] Run advanced cleanup to delete old/useless files after sorting.")

    args = parser.parse_args()
    source_path = Path(args.source).resolve()
    dest_path = Path(args.destination).resolve()

    if not source_path.is_dir() or not dest_path.is_dir():
        print(f"{Fore.RED}ERROR: Source and destination must be valid directories."); exit()

    logging.basicConfig(filename='sorter_log.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    
    print(f"\n{Style.BRIGHT}{' ' * 10}--- The Ultimate File Sorter ---{' ' * 10}")
    if args.dry_run: print(f"{Fore.YELLOW}{Style.BRIGHT}{' ' * 15}*** DRY RUN MODE ***")
    if args.cleanup_advanced: print(f"{Fore.RED}{Style.BRIGHT}{' ' * 10}*** ADVANCED CLEANUP ENABLED ***")
    print(f"\n{Fore.CYAN}Source:      {Style.BRIGHT}{source_path}")
    print(f"{Fore.CYAN}Destination: {Style.BRIGHT}{dest_path}\n")

    auto_confirm = args.yes
    if not auto_confirm:
        response = input("Begin sorting? (y/n/ya for 'yes to all'): ").lower()
        if response == 'ya':
            auto_confirm = True
            print(f"{Fore.YELLOW}Entering 'Yes to All' mode.")
        elif response != 'y':
            print("Operation cancelled."); exit()
    else:
        print(f"{Fore.YELLOW}'--yes' flag detected. Running in non-interactive mode.")

    try:
        config_tuple = load_config()
        logging.info(f"--- Starting Sort --- Source: {source_path}, Dest: {dest_path}, Dry Run: {args.dry_run}, Auto-Confirm: {auto_confirm}")
        
        sort_directory(source_path, dest_path, config_tuple, args.dry_run, auto_confirm)
        print(f"\n{Fore.GREEN}{Style.BRIGHT}✅ Sorting phase complete!")

        if args.cleanup_advanced:
            cleanup_useless_files(dest_path, config_tuple[3], args.dry_run)

        print(f"\n{Fore.GREEN}{Style.BRIGHT}✅ All operations finished! Check 'sorter_log.log' for a detailed record.")
    except Exception as e:
        print(f"\n{Fore.RED}{Style.BRIGHT}❌ An unexpected error occurred: {e}")
        logging.error(f"FATAL_ERROR: {e}", exc_info=True)